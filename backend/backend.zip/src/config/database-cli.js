require('dotenv').config();

const dbConfig = process.env.DATABASE_URL 
  ? {
      use_env_variable: 'DATABASE_URL',
      dialect: 'postgres',
      dialectOptions: {
        ssl: {
          require: true,
          rejectUnauthorized: false
        }
      }
    }
  : {
      username: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      host: process.env.DB_HOST,
      dialect: 'postgres',
    };

module.exports = {
  development: dbConfig,
  test: dbConfig,
  production: dbConfig
};
